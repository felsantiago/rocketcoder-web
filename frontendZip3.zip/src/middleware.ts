// src/middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { Ratelimit } from '@upstash/ratelimit'
import { Redis } from '@upstash/redis'
import { getSupabaseMiddlewareClient } from './shared/supabase/middlewareClient'

const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(10, '10s'), // 10 requisições por 10 segundos
})

export async function middleware(request: NextRequest) {
  console.log('🔥 Middleware executado em:', request.nextUrl.pathname)
  const res = NextResponse.next()

  const forwardedFor = request.headers.get('x-forwarded-for')
  const ip = forwardedFor?.split(',')[0]?.trim() ?? '127.0.0.1'
  const { success } = await ratelimit.limit(ip)

  if (!success) {
    return new NextResponse('Too Many Requests', { status: 429 })
  }

  if ([
    '/signin',
    '/signup',
    '/reset-password',
    '/forgot-password'
  ].includes(request.nextUrl.pathname)) {
    const supabase = getSupabaseMiddlewareClient(request, res)
    const { data: { session } } = await supabase.auth.getSession()

    if (session) {
      return NextResponse.redirect(new URL('/dashboard', request.url))
    }
  }

  return res
}

export const config = {
  matcher: ['/api/:path*', '/signin', '/signup', '/reset-password', '/forgot-password'],
}