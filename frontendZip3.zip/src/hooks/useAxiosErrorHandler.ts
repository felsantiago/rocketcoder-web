// src/hooks/useAxiosErrorHandler.ts
'use client'

import { useEffect } from 'react'
import { isAxiosError } from 'axios'
import { toast } from 'sonner'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'
import { api } from '@/infrastructure/http/api'

const NO_SESSION_ROUTES = ['/auth/signin', '/auth/signup', '/auth/forgot-password']

export function useAxiosErrorHandler() {
  const router = useRouter()
  const { logout } = useAuth()

  useEffect(() => {
    const interceptor = api.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (isAxiosError(error)) {
          const status = error.response?.status
          const message = error.message || ''
          const url = error.config?.url || ''
          const isRefreshError = message.includes('REFRESH_TOKEN_FAILED')

          // ❌ Se for rota pública (ex: login) e deu 401, mostrar erro de login
          if (status === 401 && NO_SESSION_ROUTES.some(path => url.includes(path))) {
            toast.error('Usuário ou senha inválido.')
            return Promise.reject(error)
          }

          // 🔐 Se for erro de sessão, redirecionar para login
          if (status === 401 || isRefreshError) {
            toast.error('Sessão expirada. Faça login novamente.')
            await logout()
            router.push('/signin')
            return Promise.reject(error)
          }

          toast.error(error.response?.data?.message || 'Erro inesperado.')
        }

        return Promise.reject(error)
      }
    )

    return () => {
      api.interceptors.response.eject(interceptor)
    }
  }, [logout, router])
}