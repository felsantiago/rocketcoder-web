// src/hooks/useAxiosAuth.ts
'use client'

import { useEffect } from 'react'
import { getSupabaseClient } from '@/shared/supabase/getSupabaseClient'
import { api } from '@/infrastructure/http/api'

const NO_AUTH_PATHS = ['/auth/signin', '/auth/signup', '/auth/forgot-password']

export function useAxiosAuth() {
  useEffect(() => {
    const interceptor = api.interceptors.request.use(async (config) => {
      const shouldSkip = NO_AUTH_PATHS.some((path) => config.url?.includes(path))
      if (shouldSkip) return config

      const supabase = getSupabaseClient()
      const { data } = await supabase.auth.getSession()
      const token = data.session?.access_token

      if (token) {
        config.headers.Authorization = `Bearer ${token}`
      }

      return config
    })

    return () => {
      api.interceptors.request.eject(interceptor)
    }
  }, [])
}