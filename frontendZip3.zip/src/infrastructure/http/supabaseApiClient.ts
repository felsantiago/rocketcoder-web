// src/shared/http/supabaseApiClient.ts
import { getSupabaseClient } from "@/shared/supabase/getSupabaseClient"

export async function callEdgeFunction<T = unknown>(name: string, payload: object): Promise<T> {
  const supabase = getSupabaseClient()

  const { data, error } = await supabase.functions.invoke(name, {
    body: payload,
  })

  if (error) {
    throw new Error(error.message)
  }

  return data as T
}

// Exemplo de uso para uma RPC
export async function callRPC<T = unknown>(name: string, params: object): Promise<T> {
  const supabase = getSupabaseClient()

  const { data, error } = await supabase.rpc(name, params)

  if (error) {
    throw new Error(error.message)
  }

  return data as T
}