// src/shared/http/api.ts
import { refreshAccessTokenOrLogout } from '@/shared/auth/refreshAccessToken'
import { getSupabaseClient } from '@/shared/supabase/getSupabaseClient'
import axios from 'axios'

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
})

const NO_AUTH_PATHS = ['/auth/signin', '/auth/signup', '/auth/forgot-password']

api.interceptors.request.use(async (config) => {
  const shouldSkip = NO_AUTH_PATHS.some(path => config.url?.includes(path))
  if (shouldSkip) return config

  const supabase = getSupabaseClient()
  const { data } = await supabase.auth.getSession()
  const token = data.session?.access_token

  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }

  return config
})

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const originalRequest = error.config
    const isPublicRoute = NO_AUTH_PATHS.some(path => originalRequest.url?.includes(path))

    if (error.response?.status === 401 && !originalRequest._retry && !isPublicRoute) {
      originalRequest._retry = true

      const newToken = await refreshAccessTokenOrLogout()
      if (!newToken) return Promise.reject(error)

      originalRequest.headers.Authorization = `Bearer ${newToken}`
      return api(originalRequest)
    }

    return Promise.reject(error)
  }
)

export { api }