// src/providers/Providers.tsx
'use client'

import { ReactNode } from 'react'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClient } from '@/shared/queryClient'
import { ThemeProvider } from 'next-themes'
import { Toaster } from '@/components/ui/toaster'
import { AuthProvider } from '@/contexts/AuthContext'
import { AxiosInterceptors } from '@/components/axios/AxiosInterceptors'
import type { Session } from '@supabase/supabase-js'
import { LoadingOverlay } from '@/components/ui/LoadingOverlay'

export function Providers({
  children,
  initialSession,
}: {
  children: ReactNode
  initialSession?: Session | null
}) {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <AuthProvider initialSession={initialSession}>
          <AxiosInterceptors />
          <LoadingOverlay />
          {children}
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  )
}