// src/shared/auth/refreshAccessToken.ts
import { getSupabaseClient } from '../supabase/getSupabaseClient'
import { toast } from 'sonner'

export async function refreshAccessTokenOrLogout(): Promise<string | null> {
  const supabase = getSupabaseClient()

  try {
    const { data, error } = await supabase.auth.refreshSession()

    if (error || !data.session) {
      throw new Error('REFRESH_TOKEN_FAILED')
    }

    return data.session.access_token
  } catch {
    toast.error('Sessão expirada. Faça login novamente.')
    await supabase.auth.signOut()
    window.location.href = '/signin'
    return null
  }
}