// src/app/layout.tsx
import './globals.css'
import { Providers } from '@/providers/Providers'
import { Header } from '@/components/header/Header'
import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import type { Metadata } from 'next'
import type { Database } from '@/shared/types/supabase'

export const metadata: Metadata = {
  title: 'Seu App',
  description: 'Descrição do seu app',
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const supabase = createServerComponentClient<Database>({ cookies })
  const {
    data: { session },
  } = await supabase.auth.getSession()

  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <Providers initialSession={session}>
          <Header />
          <main className="p-4">{children}</main>
        </Providers>
      </body>
    </html>
  )
}