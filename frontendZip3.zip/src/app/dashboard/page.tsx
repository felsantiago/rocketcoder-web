// src/app/dashboard/page.tsx (ou DashboardPage.tsx)
'use client'

import { useEffect, useState } from 'react'
import { Skeleton } from '@/components/ui/skeleton'

export default function DashboardPage() {
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<any[]>([])

  useEffect(() => {
    // Simula fetch
    setTimeout(() => {
      setData([
        { title: 'Relatórios', value: 32 },
        { title: 'Usuários', value: 105 },
        { title: 'Tarefas pendentes', value: 7 },
      ])
      setLoading(false)
    }, 2000)
  }, [])

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {loading
        ? Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="p-4 border rounded-lg bg-card shadow-sm space-y-2">
              <Skeleton className="h-6 w-2/3" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          ))
        : data.map((item, i) => (
            <div key={i} className="p-4 border rounded-lg bg-card shadow-sm">
              <h3 className="text-lg font-semibold">{item.title}</h3>
              <p className="text-muted-foreground">{item.value}</p>
            </div>
          ))}
    </div>
  )
}