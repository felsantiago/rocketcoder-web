'use client'

import { useEffect, useState } from 'react'
import { ResetPasswordForm } from '@/components/auth/ResetPasswordForm'

export default function ResetPasswordPage() {
  const [loading, setLoading] = useState(true)
  const [accessToken, setAccessToken] = useState<string | null>(null)
  const [refreshToken, setRefreshToken] = useState<string | null>(null)

  useEffect(() => {
    const hash = window.location.hash
    const params = new URLSearchParams(hash.slice(1))

    const access_token = params.get('access_token')
    const refresh_token = params.get('refresh_token')

    if (access_token) setAccessToken(access_token)
    if (refresh_token) setRefreshToken(refresh_token)

    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Carregando dados de redefinição…</p>
      </div>
    )
  }

  if (!accessToken) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Link inválido ou expirado.</p>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="w-full max-w-md p-8 border border-border rounded-xl shadow space-y-6">
        <h1 className="text-2xl font-semibold text-center">Redefinir senha</h1>
        <ResetPasswordForm accessToken={accessToken} refreshToken={refreshToken} />
      </div>
    </div>
  )
}