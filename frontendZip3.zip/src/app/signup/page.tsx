// src/app/signup/page.tsx
import { SignupForm } from '@/components/auth/SignupForm'

export default function SignupPage() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="w-full max-w-md p-8 border border-border rounded-xl shadow space-y-6">
        <h1 className="text-2xl font-semibold text-center">Criar conta</h1>
        <SignupForm />
        <p className="text-center text-sm">
          Já tem conta? <a href="/signin" className="text-primary underline">Entrar</a>
        </p>
      </div>
    </div>
  )
}