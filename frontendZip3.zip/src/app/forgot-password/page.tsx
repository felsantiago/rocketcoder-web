// src/app/forgot-password/page.tsx
import { ForgotPasswordForm } from '@/components/auth/ForgotPasswordForm'

export default function ForgotPasswordPage() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="w-full max-w-md space-y-6 p-8 border border-border rounded-xl shadow">
        <h1 className="text-2xl font-semibold text-center">Recuperar senha</h1>
        <ForgotPasswordForm />
      </div>
    </div>
  )
}