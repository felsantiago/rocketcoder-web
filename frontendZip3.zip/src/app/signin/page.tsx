import { LoginForm } from '@/components/auth/LoginForm'

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="w-full max-w-md space-y-6 p-8 border border-border rounded-xl shadow">
        <h1 className="text-2xl font-semibold text-center">Login</h1>
        <LoginForm />
      </div>
    </div>
  )
}