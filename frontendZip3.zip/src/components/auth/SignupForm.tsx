// src/components/auth/SignupForm.tsx
'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { signupSchema } from '@/shared/validations/authSchemas'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
import { useMutation } from '@tanstack/react-query'
import { signupUser } from '@/services/authService'
import { useRouter } from 'next/navigation'
import { mapApiErrorMessage } from '@/shared/errors/mapApiErrorMessage'
import { getApiErrorPayload } from '@/shared/errors/getApiErrorPayload'

type SignupSchema = z.infer<typeof signupSchema>

export function SignupForm() {
  const router = useRouter()
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<SignupSchema>({
    resolver: zodResolver(signupSchema),
  })

  const { mutate, isPending } = useMutation({
    mutationFn: signupUser,
    onSuccess: () => {
      toast.success('Cadastro realizado! Verifique seu e-mail para continuar.')
      router.push('/signin')
    },
    onError: (error) => {
      const apiError = getApiErrorPayload(error)
      const message = mapApiErrorMessage(apiError)
      toast.error(message)
    }
  })

  const onSubmit = (data: SignupSchema) => mutate(data)

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 w-full max-w-sm">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input type="email" id="email" {...register('email')} />
        {errors.email && <p className="text-sm text-red-500">{errors.email.message}</p>}
      </div>

      <div>
        <Label htmlFor="password">Senha</Label>
        <Input type="password" id="password" {...register('password')} />
        {errors.password && <p className="text-sm text-red-500">{errors.password.message}</p>}
      </div>

      <div>
        <Label htmlFor="confirmPassword">Confirmar senha</Label>
        <Input type="password" id="confirmPassword" {...register('confirmPassword')} />
        {errors.confirmPassword && <p className="text-sm text-red-500">{errors.confirmPassword.message}</p>}
      </div>

      <Button type="submit" className="w-full" disabled={isPending}>
        {isPending ? 'Criando...' : 'Criar conta'}
      </Button>
    </form>
  )
}