// src/components/auth/LoginForm.tsx
'use client'

import Link from 'next/link'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'
import { useRouter } from 'next/navigation'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { loginSchema } from '@/shared/validations/authSchemas'
import { loginUser } from '@/services/authService'
import { useAuth } from '@/contexts/AuthContext'
import { mapApiErrorMessage } from '@/shared/errors/mapApiErrorMessage'
import { getApiErrorPayload } from '@/shared/errors/getApiErrorPayload'

type LoginSchema = z.infer<typeof loginSchema>

export function LoginForm() {
  const router = useRouter()
  const { login } = useAuth()

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<LoginSchema>({
    resolver: zodResolver(loginSchema),
  })

  const { mutate, isPending, isError } = useMutation({
    mutationFn: loginUser,
    onSuccess: async (_data, variables) => {
      await login(variables.email, variables.password)
      router.push('/dashboard')
    },
    onError: (error) => {
      const apiError = getApiErrorPayload(error)
      const message = mapApiErrorMessage(apiError)
      toast.error(message)
    }
  })

  function onSubmit(data: LoginSchema) {
    mutate(data)
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 w-full max-w-sm">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          {...register('email')}
          className={isError ? 'border-red-500' : ''}
          autoComplete="email"
        />
        {errors.email && <p className="text-sm text-red-500">{errors.email.message}</p>}
      </div>

      <div>
        <Label htmlFor="password">Senha</Label>
        <Input
          id="password"
          type="password"
          {...register('password')}
          className={isError ? 'border-red-500' : ''}
          autoComplete="current-password"
        />
        {errors.password && <p className="text-sm text-red-500">{errors.password.message}</p>}
      </div>

      {isError && (
        <p className="text-sm text-red-500">
          Email ou senha inválido. Tente novamente.
        </p>
      )}

      <div className="flex justify-end">
        <Link href="/forgot-password" className="text-sm text-primary hover:underline">
          Esqueci minha senha
        </Link>
      </div>

      <Button type="submit" className="w-full" disabled={isPending}>
        {isPending ? 'Entrando...' : 'Entrar'}
      </Button>

      <p className="text-sm text-center text-muted-foreground">
        Não tem uma conta?{' '}
        <Link href="/signup" className="underline text-primary hover:opacity-80">
          Criar conta
        </Link>
      </p>
    </form>
  )
}