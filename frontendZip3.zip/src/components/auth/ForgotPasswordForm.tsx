// src/components/auth/ForgotPasswordForm.tsx
'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'

import { forgotPasswordSchema } from '@/shared/validations/authSchemas'
import { forgotPasswordReset } from '@/services/authService'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { mapApiErrorMessage } from '@/shared/errors/mapApiErrorMessage'
import { getApiErrorPayload } from '@/shared/errors/getApiErrorPayload'

const schema = forgotPasswordSchema
type ForgotPasswordSchema = z.infer<typeof schema>

export function ForgotPasswordForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ForgotPasswordSchema>({
    resolver: zodResolver(schema),
  })

  const { mutate, isPending } = useMutation({
    mutationFn: forgotPasswordReset,
    onSuccess: () => {
      toast.success('Verifique seu e-mail para redefinir sua senha.')
    },
    onError: (error) => {
      const apiError = getApiErrorPayload(error)
      const message = mapApiErrorMessage(apiError)
      toast.error(message)
    }
  })

  function onSubmit(data: ForgotPasswordSchema) {
    mutate(data)
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 w-full max-w-sm">
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" type="email" {...register('email')} />
        {errors.email && <p className="text-sm text-red-500">{errors.email.message}</p>}
      </div>

      <Button type="submit" className="w-full" disabled={isPending}>
        {isPending ? 'Enviando...' : 'Recuperar senha'}
      </Button>
    </form>
  )
}