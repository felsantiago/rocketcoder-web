'use client'

import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { resetPasswordSchema } from '@/shared/validations/authSchemas'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
import { useMutation } from '@tanstack/react-query'
import { resetPassword } from '@/services/authService'
import { useRouter } from 'next/navigation'
import { mapApiErrorMessage } from '@/shared/errors/mapApiErrorMessage'
import { getApiErrorPayload } from '@/shared/errors/getApiErrorPayload'

type ResetSchema = z.infer<typeof resetPasswordSchema>

interface ResetPasswordFormProps {
  accessToken: string
}

interface ResetPasswordFormProps {
  accessToken: string
  refreshToken?: string | null
}

export function ResetPasswordForm({ accessToken, refreshToken }: ResetPasswordFormProps) {
  const router = useRouter()

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ResetSchema>({
    resolver: zodResolver(resetPasswordSchema),
  })

  const { mutate, isPending } = useMutation({
    mutationFn: async (data: ResetSchema) => {
      return resetPassword(data, accessToken, refreshToken)
    },
    onSuccess: async () => {
      toast.success('Senha redefinida com sucesso! Faça login novamente.')
      router.push('/signin')
    },
    onError: (error) => {
      const apiError = getApiErrorPayload(error)
      const message = mapApiErrorMessage(apiError)
      toast.error(message)
    }
  })

  return (
    <form onSubmit={handleSubmit((data) => mutate(data))} className="space-y-4 w-full max-w-sm">
      <div>
        <Label htmlFor="new_password">Nova senha</Label>
        <Input id="new_password" type="password" {...register('new_password')} />
        {errors.new_password && <p className="text-sm text-red-500">{errors.new_password.message}</p>}
      </div>

      <div>
        <Label htmlFor="confirm_password">Confirmar senha</Label>
        <Input id="confirm_password" type="password" {...register('confirm_password')} />
        {errors.confirm_password && <p className="text-sm text-red-500">{errors.confirm_password.message}</p>}
      </div>

      <Button type="submit" className="w-full" disabled={isPending}>
        {isPending ? 'Redefinindo...' : 'Redefinir senha'}
      </Button>
    </form>
  )
}