'use client'

import { useAxiosAuth } from '@/hooks/useAxiosAuth'
import { useAxiosErrorHandler } from '@/hooks/useAxiosErrorHandler'

export function AxiosInterceptors() {
  useAxiosAuth()
  useAxiosErrorHandler()

  return null
}