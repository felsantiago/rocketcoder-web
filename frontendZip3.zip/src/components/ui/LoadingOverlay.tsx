// src/components/ui/LoadingOverlay.tsx
'use client'

import { useLoading } from '@/contexts/LoadingContext'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Loader2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

export function LoadingOverlay() {
  const { isLoading } = useLoading()

  return (
    <AnimatePresence>
      {isLoading && (
        <Dialog open={true}>
          <DialogContent
            className="flex items-center justify-center bg-background border-none shadow-none [&>button.dialog-close]:hidden"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.2 }}
              className="text-center"
            >
              <Button
                variant="ghost"
                className="pointer-events-none text-base font-normal"
                disabled
              >
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Carregando...
              </Button>
            </motion.div>
          </DialogContent>
        </Dialog>
      )}
    </AnimatePresence>
  )
}