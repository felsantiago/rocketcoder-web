'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ThemeSwitcher } from '../theme/ThemeSwitcher'
import { useAuth } from '@/contexts/AuthContext'
import { UserMenu } from '@/components/header/UserMenu'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'

export function Header() {
  const { user, loading } = useAuth()
  const pathname = usePathname()
  const isOnLoginPage = pathname === '/signin'

  console.log('Auth state:', { user, loading })

  return (
    <header className="flex items-center justify-between p-4 border-b bg-background">
      <Link href="/" className="text-xl font-bold">
        Code Wingman
      </Link>

      <div className="flex items-center gap-4">
        <ThemeSwitcher />

        {loading ? (
          <Skeleton className="w-10 h-10 rounded-full" />
        ) : user ? (
          <UserMenu />
        ) : (
          !isOnLoginPage && (
            <Link href="/signin">
              <Button variant="outline">Login</Button>
            </Link>
          )
        )}
      </div>
    </header>
  )
}