import { api } from '@/infrastructure/http/api'

interface LoginPayload {
  email: string
  password: string
}

interface SignupPayload {
  email: string
  password: string
}

interface ForgotPasswordPayload {
  email: string
}

interface ResetPasswordPayload {
  new_password: string
  confirm_password: string
}

export async function loginUser(data: LoginPayload) {
  const response = await api.post('/auth/signin', data)
  return response.data
}

export async function signupUser(data: SignupPayload) {
  const response = await api.post('/auth/signup', data)
  return response.data
}

export async function forgotPasswordReset(data: ForgotPasswordPayload) {
  const response = await api.post('/auth/forgot-password', data)
  return response.data
}

export async function resetPassword(
  data: ResetPasswordPayload,
  token: string,
  refreshToken?: string | null
) {
  const response = await api.post('/auth/reset-password', {
    new_password: data.new_password,
    confirm_password: data.confirm_password,
  }, {
    headers: {
      Authorization: `Bearer ${token}`,
      ...(refreshToken && { 'x-refresh-token': refreshToken }),
    },
  })

  return response.data
}